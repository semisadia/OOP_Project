/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author User
 */
public class FXMLAdministratorController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void meettingOnClick(ActionEvent event) throws IOException {
        
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FxmlCreateMeeting.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
        //controller4.initDataHea( Administrator);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }

    @FXML
    private void createFlightScheduleOnClick(ActionEvent event) throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLCreatFlightSchedule.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
        //controller4.initDataHea( Administrator);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }

    
    @FXML
    private void createNoticeOnClick(ActionEvent event) throws IOException  {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("CreatNotice.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
        //controller4.initDataHea( Administrator);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    
    }

    @FXML
    private void createBillOnClick(ActionEvent event)throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLCreateBill.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
        //controller4.initDataHea( Administrator);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    
    }

    @FXML
    private void viewMessageOnClick(ActionEvent event)throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLPilotNoticeView.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
        //controller4.initDataHea( Administrator);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    
    }

    @FXML
    private void logoutOnClick(ActionEvent event) throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("loginPage.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
        //controller4.initDataHea( Administrator);
        Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
        window4.setScene(homepage4);
        window4.show();
    }
    
}
