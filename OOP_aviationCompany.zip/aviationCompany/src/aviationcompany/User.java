package aviationcompany;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;

import java.util.ArrayList;

public abstract class User implements Serializable {
    
    protected String name,user_type,password;
  
    protected int id;
    
    public User(String name, int id, String user_type,  String password){
       this.id = id;
       this.name = name;
       this.user_type = user_type;
       this.password = password;
                    
    }
    
    public abstract void addUser();

    @Override
    public String toString() {
        return "User{" + "name=" + name + ", user_type=" + user_type + ", password=" + password + ", id=" + id + '}';
    }
    
    public String dispaly(){
        return "Name: "+name+"\nID:"+id+"\nType: "+user_type+"\nPassword: "+password+"\n\n";
    }

    public String getUser_type() {
        return user_type;
    }

    public String getPassword() {
        return password;
    }

    public int getId() {
        return id;
    }
    
    public static User login(int ID, String pass, String type){
        ArrayList<User>uList = User.listOfUser();
        for(User i: uList){
            if(i.getId()==ID && i.getUser_type().equals(type) && i.getPassword().equals(pass)){
                return i;
            }
        }
        return null;
    }
    
    
    public static ArrayList<User> listOfUser(){
        ArrayList<User>uList = new ArrayList<>();
        
        File f = null;
        FileInputStream fis = null;      
        ObjectInputStream ois = null;
        
        try {
            f = new File("User.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            User u;
            try{
                while(true){
                    u = (User)ois.readObject();
                    uList.add(u);
                }
            }//end of nested try
            catch(Exception e){
                //
            }//nested catch                 
        } catch (IOException ex) { } 
        finally {
            try {
                if(ois != null) ois.close();
            } catch (IOException ex) { }
        }    
        return uList;
    
    }

}
