/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.scene.Node;

/**
 * FXML Controller class
 *
 * @author User
 */
public class FXMLMeetingViewTableCEOController implements Initializable {

    @FXML
    private TableView<meeting> tableView;
    @FXML
    private TableColumn<meeting, String> meetingID;
    @FXML
    private TableColumn<meeting, String> perposeID;
    @FXML
    private TableColumn<meeting, String> TimeID;
    @FXML
    private TableColumn<meeting,String> Dateid;
    @FXML
    private TableColumn<meeting,String> ApprovalID;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        meetingID.setCellValueFactory(new PropertyValueFactory<meeting, String>("meetingId"));
        perposeID.setCellValueFactory(new PropertyValueFactory<meeting, String>("purpose"));
        TimeID.setCellValueFactory(new PropertyValueFactory<meeting, String>("time"));
        Dateid.setCellValueFactory(new PropertyValueFactory<meeting, String>("date"));
        ApprovalID.setCellValueFactory(new PropertyValueFactory<meeting,String>("appoval"));
        
        
      loadmeetingFile();  
      tableView.setEditable(true);
      ApprovalID.setCellFactory(TextFieldTableCell.forTableColumn());
         
        
    }    
    
    
    private void loadmeetingFile() {
         ObjectInputStream ois=null;
         try {
            meeting s;
            ois = new ObjectInputStream(new FileInputStream("Createmeeting.bin"));
            while(true){
            s = (meeting) ois.readObject();
            s.display();
            tableView.getItems().add(s);
            }
            
        } catch (Exception ex) {
            try {
                if(ois!=null)
                    ois.close();
            } 
            catch (IOException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        }        
    }

    @FXML
    private void backOnClick(ActionEvent event) throws IOException{
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLCEO.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
     //controller4.initDataHea( Administrator);
      Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
      window4.setScene(homepage4);
      window4.show();
    }
}
