/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;
import java.io.Serializable;
/**
 *
 * @author User
 */
public class bill implements Serializable {
    private static final long serialVersionUID = 1L;
    String passengerName;
    String emailAddress;  
    String currentAddress;
    String visitingAddress;
    String offer;
    String totalAmount;
    String netPayableAmount;

    
    public bill(String passengerName,String emailAddress,String currentAddress,String visitingAddress,String offer,String totalAmount,String netPayableAmount) {  
        this.passengerName=passengerName;
        this.emailAddress=emailAddress;
        this.currentAddress=currentAddress;  
        this.visitingAddress=visitingAddress;
         this.offer=offer;
        this.totalAmount= totalAmount;
         this.netPayableAmount= netPayableAmount;
    }
    
    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }
    
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public void setCurrentAddress(String currentAddress) {
        this.currentAddress = currentAddress;
    }
    
    public void setVisitingAddress(String visitingAddress) {
        this.visitingAddress = visitingAddress;
    }
    public void setOffer(String offer) {
        this.offer = offer;
    }
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }
    public void setNetPayableAmount(String netPayableAmount ) {
        this.netPayableAmount = netPayableAmount;
    }
    
     
    public String getpassengerName() {
        return passengerName;
    }
    
    public String getemailAddress() {
        return emailAddress;
    }
    public String getcurrentAddress() {
        return currentAddress;
    }
    
    public String getvisitingAddress() {
        return visitingAddress;
    }
    public String offer() {
        return offer;
    }
    
    public String gettotalAmount() {
        return totalAmount;
    }
    public String getnetPayableAmount() {
        return netPayableAmount;
    }
    
    @Override
    public String toString(){
        return "Passenger Name= "+passengerName+",\n Email Address= "+emailAddress+", \nCurrent Address= "+currentAddress+", \nVisiting Address= "+visitingAddress+", \nTotal Offer= "+offer+",\n Total Amount= "+totalAmount+", \nNet Payable Amount= "+netPayableAmount;
         }
    
    public void display(){
        System.out.println("\nPassenger Name=\n"+passengerName+",Email Address=\n"+emailAddress+",Current Address=\n"+currentAddress+", Visiting Address=\n"+visitingAddress+",Offer=\n"+offer+",TotalAmount=\n"+totalAmount+",net Payable Amount=\n"+netPayableAmount);
    }

    String getoffer() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}

    

    

