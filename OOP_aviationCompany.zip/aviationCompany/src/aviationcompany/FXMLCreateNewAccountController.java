/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
/**
 * FXML Controller class
 *
 * @author mohsi
 */
public class FXMLCreateNewAccountController implements Initializable {
    private User user;
    void initData(User user) {
        this.user = user;
    }
    
    @FXML
    private TextField idField;
    @FXML
    private TextField nameField;
   
    @FXML
    private TextField passField;
    @FXML
    private TextArea outputTextArea;
    @FXML
    private ComboBox<String> userTypeField;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        userTypeField.getItems().addAll("CEO","Administrator","Pilot","Passenger","DataController");
    }    

    @FXML
    private void clickOnReadButton(ActionEvent event) {
        outputTextArea.setText("");
        
        ArrayList<User>u = User.listOfUser();
        if(!u.isEmpty()){
            System.out.println("Working");
            for(User i: u){
                outputTextArea.appendText(i.dispaly());
            }
        }
        outputTextArea.appendText("All objects are loaded successfully...\n");
    }

    @FXML
    private void clickOnSubmitButton(ActionEvent event) {
        if(userTypeField.getValue().equals("Administrator")){
            Administrator h = new Administrator(
                nameField.getText(),
                Integer.parseInt(idField.getText()),
                userTypeField.getValue(),
                passField.getText()
                
            );
            h.addUser();
        }
        
        if(userTypeField.getValue().equals("CEO")){
            CEO h = new CEO(
                nameField.getText(),
                Integer.parseInt(idField.getText()),
                userTypeField.getValue(),
                passField.getText()
                
            );
            h.addUser();
        }
         if(userTypeField.getValue().equals("DataController")){
            DataController h = new DataController(
                nameField.getText(),
                Integer.parseInt(idField.getText()),
                userTypeField.getValue(),
               
                passField.getText()
               
            );
            h.addUser();
        }
           if(userTypeField.getValue().equals("Passenger")){
            Passenger h = new Passenger(
                nameField.getText(),
                Integer.parseInt(idField.getText()),
                userTypeField.getValue(),
                passField.getText()
                
            );
            h.addUser();
        }
           if(userTypeField.getValue().equals ("Pilot")){
            Pilot h = new Pilot(
                nameField.getText(),
                Integer.parseInt(idField.getText()),
                userTypeField.getValue(),
                passField.getText()
              
            );
            h.addUser();
        }
        
        nameField.clear();
        idField.clear();
        passField.clear();
       
    }

    @FXML
    private void backOnClick(ActionEvent event) throws IOException{
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLDataController.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
     //controller4.initDataHea( Administrator);
      Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
      window4.setScene(homepage4);
      window4.show();
        //todo
    }


    
    
   
    
    
}
    


