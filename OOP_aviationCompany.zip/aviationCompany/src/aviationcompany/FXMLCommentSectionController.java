/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
/**
 * FXML Controller class
 *
 * @author User
 */
public class FXMLCommentSectionController implements Initializable {

    @FXML
    private TextArea addComment;
    @FXML
    private TextArea viewComment;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    
    @FXML
    private void postOnclick(ActionEvent event) throws IOException {
        File f=null;
        FileWriter fw=null;
        try{
            f = new File("CommentSection.txt");
            if(f.exists())fw=new FileWriter(f,true);
            else fw=new FileWriter(f);
            fw.write(
            addComment.getText()+"\n"
            );
            
        }catch(IOException ex){
            
        }finally{
            try{
                if(fw!=null)fw.close();
                        
            }catch(IOException ex){
        }
        }
    }
    
    
    @FXML
    private void viewcommentOnclick(ActionEvent event) throws FileNotFoundException{
        viewComment.setText("");
        File file = new File("CommentSection.txt");
        Scanner sc;
        String str=null;
        try{
            sc = new Scanner(file);
            viewComment.setText(null);
            while(sc.hasNextLine()){
                str=sc.nextLine();
                viewComment.appendText(str+"\n");
            }
        }catch(FileNotFoundException ex){
    }
    }

    @FXML
    private void backOnClick(ActionEvent event)throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLCEO.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
     //controller4.initDataHea( Administrator);
      Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
      window4.setScene(homepage4);
      window4.show();
    }
    
    
    
    
    


    

}    
    
    

