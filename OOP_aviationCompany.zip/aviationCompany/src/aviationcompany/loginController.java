package aviationcompany;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;


public class loginController implements Initializable {
    
    
    @FXML
    private AnchorPane bcimg;
    @FXML
    private BorderPane bcin;
    @FXML
    private TextField idfill;
    @FXML
    private ComboBox<String> user_type;
    @FXML
    private TextField passwordfil;
    @FXML
    private Label label;

   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        ArrayList<User>uList = User.listOfUser();
        for(User i : uList){
            System.out.println(i.dispaly());
        }
        user_type.getItems().addAll("Administrator","CEO","Pilot","Passenger","DataController");
        label.setText("");
    }    

    @FXML
    private void signInBtnOnClick(ActionEvent event) throws IOException {
        User u = User.login(
                Integer.parseInt(idfill.getText()),
                passwordfil.getText(),
                user_type.getValue().toString()
                );
        if(u==null){
            label.setText("User-ID, Password and User Type combination failed. Try again!");
            idfill.setText("");
            passwordfil.setText("");
            user_type.setValue("User Type");
        }
         else{
             if(u instanceof Administrator){
                 
                 
                 FXMLLoader loader3 = new FXMLLoader();
                 loader3.setLocation(getClass().getResource("FXMLAdministrator.fxml"));
                 Parent homeScene3 = loader3.load();
                 Scene homepage3 = new Scene(homeScene3);
                 FXMLAdministratorController controller = loader3.getController();
                 //controller.initData(u);
                 Stage window3 = (Stage)((Node)event.getSource()).getScene().getWindow();
                 window3.setScene(homepage3);
                 window3.show();
             }
             
             //if (u instanceof CEO) {
        
             
                 if (u instanceof CEO) {
                 FXMLLoader loader5 = new FXMLLoader();
                 loader5.setLocation(getClass().getResource("FXMLCEO.fxml"));
                 Parent homeScene5 = loader5.load();
                 Scene homepage5 = new Scene(homeScene5);
                 FXMLCEOController controller = loader5.getController();
                 // controller5.initData(u);
               Stage window5 = (Stage) ((Node) event.getSource()).getScene().getWindow();
                 window5.setScene(homepage5);
                 window5.show();
            }

              if (u instanceof Pilot) {
                 FXMLLoader loader5 = new FXMLLoader();
                 loader5.setLocation(getClass().getResource("FXMLPilot.fxml"));
                 Parent homeScene5 = loader5.load();
                 Scene homepage5 = new Scene(homeScene5);
                 FXMLPilotController controller4 = loader5.getController();
                 // controller5.initData(u);
                 Stage window5 = (Stage) ((Node) event.getSource()).getScene().getWindow();
                 window5.setScene(homepage5);
                window5.show();
             }

             if (u instanceof Passenger) {
                 FXMLLoader loader5 = new FXMLLoader();
                loader5.setLocation(getClass().getResource("FXMLPassenger.fxml"));
                 Parent homeScene5 = loader5.load();
                 Scene homepage5 = new Scene(homeScene5);
                 FXMLPassengerController controller5 = loader5.getController();
                 // controller5.initData(u);
                 Stage window5 = (Stage) ((Node) event.getSource()).getScene().getWindow();
                 window5.setScene(homepage5);
                 window5.show();
           } 
        if (u instanceof DataController) {
                 FXMLLoader loader5 = new FXMLLoader();
                loader5.setLocation(getClass().getResource("FXMLDataController.fxml"));
                 Parent homeScene5 = loader5.load();
                 Scene homepage5 = new Scene(homeScene5);
                 FXMLDataControllerController controller5 = loader5.getController();
                 // controller5.initData(u);
                 Stage window5 = (Stage) ((Node) event.getSource()).getScene().getWindow();
                 window5.setScene(homepage5);
                 window5.show();
           } 
        
        
        }
    }
}
