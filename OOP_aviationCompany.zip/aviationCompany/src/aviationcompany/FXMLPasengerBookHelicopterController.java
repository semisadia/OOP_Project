/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;

/**
 * FXML Controller class
 *
 * @author User
 */
public class FXMLPasengerBookHelicopterController implements Initializable {

    @FXML
    private TextField nameText;
    @FXML
    private TextField addressText;
    @FXML
    private TextField mobileText;
    @FXML
    private ComboBox<String> selectHtext;
    @FXML
    private ComboBox<String> selectTText;
    @FXML
    private TextArea viewPassengerInfo;
    @FXML
    private TextArea editpassengerInfo;
    @FXML
    private CheckBox editinfocheckbox;
    
    ObservableList<String> list1 = FXCollections.observableArrayList("Bell 206", "Airbus Helicopters AS350","Airbus Helicopters EC135");
    ObservableList<String> list2 = FXCollections.observableArrayList("8:00 AM", "10:00 AM","2:00 PM");

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       selectHtext.setItems(list1);
       selectTText.setItems(list2);
    }    

    @FXML
    private void submitInformationOnClick(ActionEvent event) {
         File f = null;
        FileWriter fw = null;
        try {
          
            f = new File("passengerInfo.txt");
            if(f.exists()) fw = new FileWriter(f,true);
            else fw = new FileWriter(f);
           
            fw.write(
                nameText.getText()+","
                +addressText.getText()+","	
                +mobileText.getText()+","
                +selectHtext.getValue()+","
                +selectTText.getValue()+"\n"	
                	
            );           
           
        } catch (IOException ex) {
            //TODO
        } finally {
          try {
              if(fw != null) fw.close();
          } catch (IOException ex) {
              //TODO
          }
      }
    }

    @FXML
    private void viewInformationOnClick(ActionEvent event) {
        viewPassengerInfo.setText("");
         editpassengerInfo.clear();
        File file = new File("passengerInfo.txt");
        Scanner sc; String str=null;
        try {
            sc = new Scanner(file);
            viewPassengerInfo.setText(null);
            while(sc.hasNextLine()){
                str=sc.nextLine();
                viewPassengerInfo.appendText(str+"\n");
                            
            }
        } catch (FileNotFoundException ex) {
           //todo
        }   
    }

    
    @FXML
    private void editInfoOnClick(ActionEvent event) {
        if(editinfocheckbox.isSelected()){
           editpassengerInfo.setEditable(true);
            editpassengerInfo.setText(viewPassengerInfo.getText());
        }
        else{
           editpassengerInfo.setText(null);
           editpassengerInfo.setEditable(false);
        }
    }
    
    @FXML
    private void saveEditOnclick(ActionEvent event) {
        try {
            File file = new File("passengerInfo.txt");
            if (!file.exists()) {
               //todo
            }
            BufferedWriter out = new BufferedWriter(new FileWriter(file));
            out.write( editpassengerInfo.getText());
            out.newLine();
            out.close();
        } catch (Exception e) {
            // TODO: handle exception
        }
    }

    @FXML
    private void backOnClick(ActionEvent event)throws IOException {
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLPassenger.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
     //controller4.initDataHea( Administrator);
      Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
      window4.setScene(homepage4);
      window4.show();
    }

    
}
