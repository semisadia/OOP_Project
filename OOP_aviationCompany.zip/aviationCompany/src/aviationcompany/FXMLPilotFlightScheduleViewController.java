/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;
import javafx.scene.Node;

/**
 * FXML Controller class
 *
 * @author User
 */
public class FXMLPilotFlightScheduleViewController implements Initializable {

    
    @FXML
    private TableView<schedule> flightTableView;
    @FXML
    private TableColumn<schedule, String> flightNameTableView;
    @FXML
    private TableColumn<schedule, String> placetableview;
    @FXML
    private TableColumn<schedule, String> datetableview;
    @FXML
    private TableColumn<schedule, String> timetableview;
    @FXML
    private TableColumn<schedule, String> idtableview;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        flightNameTableView.setCellValueFactory(new PropertyValueFactory<schedule,String>("flightname"));
        placetableview.setCellValueFactory(new PropertyValueFactory<schedule, String>("place"));
        datetableview.setCellValueFactory(new PropertyValueFactory<schedule, String>("time"));
        timetableview.setCellValueFactory(new PropertyValueFactory<schedule, String>("date"));
        idtableview.setCellValueFactory(new PropertyValueFactory<schedule,String>("helicopterid"));
        
        
         loadscheduleFile();  
      
  
    }    

    //private void loadscheduleFile() {
    //    throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    //}
    private void loadscheduleFile() {
         ObjectInputStream ois=null;
         try {
            schedule s;
            ois = new ObjectInputStream(new FileInputStream("Createflightschedule.bin"));
            while(true){
            s = (schedule)ois.readObject();
            s.display();
            flightTableView.getItems().add(s);
            }
            
        } catch (Exception ex) {
            try {
                if(ois!=null)
                    ois.close();
            } 
            catch (IOException e) {
                e.printStackTrace();
            }
            ex.printStackTrace();
        }        
    }

    @FXML
    private void backOnClick(ActionEvent event) throws IOException{
        FXMLLoader loader4 = new FXMLLoader();
        loader4.setLocation(getClass().getResource("FXMLPilot.fxml"));
        Parent homeScene4 = loader4.load();
        Scene homepage4 = new Scene(homeScene4);
        //FXMLAdministratorHomeScene controller4 = loader4.getController();
     //controller4.initDataHea( Administrator);
      Stage window4 = (Stage)((Node)event.getSource()).getScene().getWindow();
      window4.setScene(homepage4);
      window4.show();
    }
}

    
    
