/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.Serializable;

/**
 *
 * @author User
 */




public class schedule implements Serializable {
    String flightname;
    String place;  
    String date;
    String time;
    String helicopterid;
    
    
    public schedule(String flightname,String place,String date,String time,String helicopterid) {  
        this.flightname=flightname;
        this.place=place;
        this.time = time;  
        this.date = date;
        this.helicopterid = helicopterid;
    }
    
    public void setFlightname(String flightname) {
        this.flightname = flightname;
    }
    
    public void setPlace(String place) {
        this.place =place;
    }
    public void setTime(String time) {
        this.time = time;
    }
    
    public void setDate(String date) {
        this.date = date;
    }
    
    public void setHelicopterid(String helicopterid) {
        this.helicopterid = helicopterid;
    }
     
    public String getFlightname() {
        return flightname;
    }
    
    public String getPlace() {
        return place;
    }
    public String getTime() {
        return time;
    }
    
    public String getDate() {
        return date;
    }
    
    public String getHelicopterid() {
        return helicopterid;
    }
    
    @Override
    public String toString(){
        return "Flight name="+flightname+",Place="+place+", Time="+time+", Date="+date+", Helicopter Id="+helicopterid;
    }
    
    public void display(){
        System.out.println("Flight name="+flightname+",Place="+place+", Time="+time+", Date="+date+", Helicopter Id="+helicopterid
    );
    }
}

