/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aviationcompany;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.IOException;
import java.io.ObjectInputStream;


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
/**
 * FXML Controller class
 *
 * @author User
 */
public class FXMLPassengerShowBillController implements Initializable {

    @FXML
    private TextArea showBill;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        viewNoticeOnClick();
    }    
    private void viewNoticeOnClick() {
        showBill.setText("");
        ObjectInputStream ois=null;
        String r = "";
        try {
           bill s;
           ois = new ObjectInputStream(new FileInputStream("Createbill.bin"));
           while(true){
           s = (bill) ois.readObject();
           r +=s.toString();
          showBill.setText(r);
           }
       } catch (IOException | ClassNotFoundException ex) {
           try {
               if(ois!=null)
                   ois.close();
           } 
           catch (IOException e) {
           }
       }        
}

}
